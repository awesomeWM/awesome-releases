/*
 * statusbar.c - statusbar functions
 *
 * Copyright © 2007-2008 Julien Danjou <julien@danjou.info>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 *
 */

#include <xcb/xcb.h>

#include "client.h"
#include "statusbar.h"
#include "screen.h"
#include "widget.h"
#include "ewmh.h"

extern awesome_t globalconf;

DO_LUA_NEW(extern, statusbar_t, statusbar, "statusbar", statusbar_ref)
DO_LUA_GC(statusbar_t, statusbar, "statusbar", statusbar_unref)
DO_LUA_EQ(statusbar_t, statusbar, "statusbar")

/** Kick out systray windows.
 * \param phys_screen Physical screen number.
 */
static void
statusbar_systray_kickout(int phys_screen)
{
    xembed_window_t *em;
    uint32_t config_win_vals_off[2] = { -512, -512 };

    for(em = globalconf.embedded; em; em = em->next)
        if(em->phys_screen == phys_screen)
            xcb_configure_window(globalconf.connection, em->win,
                                 XCB_CONFIG_WINDOW_X
                                 | XCB_CONFIG_WINDOW_Y,
                                 config_win_vals_off);
}

static void
statusbar_systray_refresh(statusbar_t *statusbar)
{
    widget_node_t *systray;

    if(statusbar->screen == SCREEN_UNDEF)
        return;

    for(systray = statusbar->widgets; systray; systray = systray->next)
        if(systray->widget->type == systray_new)
        {
            uint32_t config_win_vals[4];
            uint32_t config_win_vals_off[2] = { -512, -512 };
            xembed_window_t *em;
            position_t pos;

            if(statusbar->position
               && systray->widget->isvisible)
            {
                pos = statusbar->position;
                /* width */
                config_win_vals[2] = systray->area.height;
                /* height */
                config_win_vals[3] = systray->area.height;
            }
            else
                /* hide */
                pos = Off;

            switch(pos)
            {
              case Left:
                config_win_vals[0] = statusbar->sw->geometry.x + systray->area.y;
                config_win_vals[1] = statusbar->sw->geometry.y + statusbar->sw->geometry.height
                    - systray->area.x - config_win_vals[3];
                for(em = globalconf.embedded; em; em = em->next)
                    if(em->phys_screen == statusbar->phys_screen)
                    {
                        if(em->info.flags & XEMBED_MAPPED
                           && config_win_vals[1] - config_win_vals[2] >= (uint32_t) statusbar->sw->geometry.y)
                        {
                            xcb_map_window(globalconf.connection, em->win);
                            xcb_configure_window(globalconf.connection, em->win,
                                                 XCB_CONFIG_WINDOW_X
                                                 | XCB_CONFIG_WINDOW_Y
                                                 | XCB_CONFIG_WINDOW_WIDTH
                                                 | XCB_CONFIG_WINDOW_HEIGHT,
                                                 config_win_vals);
                            config_win_vals[1] -= config_win_vals[3];
                        }
                        else
                            xcb_configure_window(globalconf.connection, em->win,
                                                 XCB_CONFIG_WINDOW_X
                                                 | XCB_CONFIG_WINDOW_Y,
                                                 config_win_vals_off);
                    }
                client_stack();
                break;
              case Right:
                config_win_vals[0] = statusbar->sw->geometry.x - systray->area.y;
                config_win_vals[1] = statusbar->sw->geometry.y + systray->area.x;
                for(em = globalconf.embedded; em; em = em->next)
                    if(em->phys_screen == statusbar->phys_screen)
                    {
                        if(em->info.flags & XEMBED_MAPPED
                           && config_win_vals[1] + config_win_vals[3] <= (uint32_t) statusbar->sw->geometry.y + statusbar->ctx->width)
                        {
                            xcb_map_window(globalconf.connection, em->win);
                            xcb_configure_window(globalconf.connection, em->win,
                                                 XCB_CONFIG_WINDOW_X
                                                 | XCB_CONFIG_WINDOW_Y
                                                 | XCB_CONFIG_WINDOW_WIDTH
                                                 | XCB_CONFIG_WINDOW_HEIGHT,
                                                 config_win_vals);
                            config_win_vals[1] += config_win_vals[3];
                        }
                        else
                            xcb_configure_window(globalconf.connection, em->win,
                                                 XCB_CONFIG_WINDOW_X
                                                 | XCB_CONFIG_WINDOW_Y,
                                                 config_win_vals_off);
                    }
                client_stack();
                break;
              case Top:
              case Bottom:
                config_win_vals[0] = statusbar->sw->geometry.x + systray->area.x;
                config_win_vals[1] = statusbar->sw->geometry.y + systray->area.y;
                for(em = globalconf.embedded; em; em = em->next)
                    if(em->phys_screen == statusbar->phys_screen)
                    {
                        /* if(x + width < systray.x + systray.width) */
                        if(em->info.flags & XEMBED_MAPPED
                           && config_win_vals[0] + config_win_vals[2] <= (uint32_t) AREA_RIGHT(systray->area) + statusbar->sw->geometry.x)
                        {
                            xcb_map_window(globalconf.connection, em->win);
                            xcb_configure_window(globalconf.connection, em->win,
                                                 XCB_CONFIG_WINDOW_X
                                                 | XCB_CONFIG_WINDOW_Y
                                                 | XCB_CONFIG_WINDOW_WIDTH
                                                 | XCB_CONFIG_WINDOW_HEIGHT,
                                                 config_win_vals);
                            config_win_vals[0] += config_win_vals[2];
                        }
                        else
                            xcb_configure_window(globalconf.connection, em->win,
                                                 XCB_CONFIG_WINDOW_X
                                                 | XCB_CONFIG_WINDOW_Y,
                                                 config_win_vals_off);
                    }
                client_stack();
                break;
              default:
                statusbar_systray_kickout(statusbar->phys_screen);
                break;
            }
            break;
        }
}

/** Draw a statusbar.
 * \param statusbar The statusbar to draw.
 */
static void
statusbar_draw(statusbar_t *statusbar)
{
    statusbar->need_update = false;

    if(statusbar->position)
    {
        widget_render(statusbar->widgets, statusbar->ctx, statusbar->sw->gc,
                      statusbar->sw->pixmap,
                      statusbar->screen, statusbar->position,
                      statusbar->sw->geometry.x, statusbar->sw->geometry.y,
                      statusbar, AWESOME_TYPE_STATUSBAR);
        simplewindow_refresh_pixmap(statusbar->sw);
    }

    statusbar_systray_refresh(statusbar);
}

/** Statusbar refresh function.
 */
void
statusbar_refresh(void)
{
    int screen;
    statusbar_t *statusbar;

    for(screen = 0; screen < globalconf.screens_info->nscreen; screen++)
        for(statusbar = globalconf.screens[screen].statusbar; statusbar; statusbar = statusbar->next)
            if(statusbar->need_update)
                statusbar_draw(statusbar);
}

/** Update the statusbar position. It deletes every statusbar resources and
 * create them back.
 * \param statusbar The statusbar.
 */
static void
statusbar_position_update(statusbar_t *statusbar)
{
    statusbar_t *sb;
    area_t area;
    xcb_pixmap_t dw;
    xcb_screen_t *s = NULL;
    bool ignore = false;

    globalconf.screens[statusbar->screen].need_arrange = true;

    simplewindow_delete(&statusbar->sw);
    draw_context_delete(&statusbar->ctx);

    if(statusbar->position == Off)
        return;

    area = screen_area_get(statusbar->screen,
                           NULL,
                           &globalconf.screens[statusbar->screen].padding);

    /* Top and Bottom statusbar_t have prio */
    for(sb = globalconf.screens[statusbar->screen].statusbar; sb; sb = sb->next)
    {
        /* Ignore every statusbar after me that is in the same position */
        if(statusbar == sb)
        {
            ignore = true;
            continue;
        }
        else if(ignore && statusbar->position == sb->position)
            continue;
        switch(sb->position)
        {
          case Left:
            switch(statusbar->position)
            {
              case Left:
                area.x += statusbar->height;
                break;
              default:
                break;
            }
            break;
          case Right:
            switch(statusbar->position)
            {
              case Right:
                area.x -= statusbar->height;
                break;
              default:
                break;
            }
            break;
          case Top:
            switch(statusbar->position)
            {
              case Top:
                area.y += sb->height;
                break;
              case Left:
              case Right:
                area.height -= sb->height;
                area.y += sb->height;
                break;
              default:
                break;
            }
            break;
          case Bottom:
            switch(statusbar->position)
            {
              case Bottom:
                area.y -= sb->height;
                break;
              case Left:
              case Right:
                area.height -= sb->height;
                break;
              default:
                break;
            }
            break;
          default:
            break;
        }
    }

    switch(statusbar->position)
    {
      case Right:
      case Left:
        if(!statusbar->width_user)
            statusbar->width = area.height;
        statusbar->sw =
            simplewindow_new(globalconf.connection, statusbar->phys_screen, 0, 0,
                             statusbar->height, statusbar->width, 0);
        s = xutil_screen_get(globalconf.connection, statusbar->phys_screen);
        /* we need a new pixmap this way [     ] to render */
        dw = xcb_generate_id(globalconf.connection);
        xcb_create_pixmap(globalconf.connection,
                          s->root_depth, dw, s->root,
                          statusbar->width, statusbar->height);
        statusbar->ctx = draw_context_new(globalconf.connection,
                                          statusbar->phys_screen,
                                          statusbar->width,
                                          statusbar->height,
                                          dw,
                                          &statusbar->colors.fg,
                                          &statusbar->colors.bg);
        break;
      default:
        if(!statusbar->width_user)
            statusbar->width = area.width;
        statusbar->sw =
            simplewindow_new(globalconf.connection, statusbar->phys_screen, 0, 0,
                             statusbar->width, statusbar->height, 0);
        statusbar->ctx = draw_context_new(globalconf.connection,
                                          statusbar->phys_screen,
                                          statusbar->width,
                                          statusbar->height,
                                          statusbar->sw->pixmap,
                                          &statusbar->colors.fg,
                                          &statusbar->colors.bg);
        break;
    }

    switch(statusbar->position)
    {
      default:
        switch(statusbar->align)
        {
          default:
            simplewindow_move(statusbar->sw, area.x, area.y);
            break;
          case AlignRight:
            simplewindow_move(statusbar->sw,
                              area.x + area.width - statusbar->width, area.y);
            break;
          case AlignCenter:
            simplewindow_move(statusbar->sw,
                              area.x + (area.width - statusbar->width) / 2, area.y);
            break;
        }
        break;
      case Bottom:
        switch(statusbar->align)
        {
          default:
            simplewindow_move(statusbar->sw,
                              area.x, (area.y + area.height) - statusbar->height);
            break;
          case AlignRight:
            simplewindow_move(statusbar->sw,
                              area.x + area.width - statusbar->width,
                              (area.y + area.height) - statusbar->height);
            break;
          case AlignCenter:
            simplewindow_move(statusbar->sw,
                              area.x + (area.width - statusbar->width) / 2,
                              (area.y + area.height) - statusbar->height);
            break;
        }
        break;
      case Left:
        switch(statusbar->align)
        {
          default:
            simplewindow_move(statusbar->sw, area.x,
                              (area.y + area.height) - statusbar->sw->geometry.height);
            break;
          case AlignRight:
            simplewindow_move(statusbar->sw, area.x, area.y);
            break;
          case AlignCenter:
            simplewindow_move(statusbar->sw, area.x, (area.y + area.height - statusbar->width) / 2);
        }
        break;
      case Right:
        switch(statusbar->align)
        {
          default:
            simplewindow_move(statusbar->sw, area.x + area.width - statusbar->height, area.y);
            break;
          case AlignRight:
            simplewindow_move(statusbar->sw, area.x + area.width - statusbar->height,
                              area.y + area.height - statusbar->width);
            break;
          case AlignCenter:
            simplewindow_move(statusbar->sw, area.x + area.width - statusbar->height,
                              (area.y + area.height - statusbar->width) / 2);
            break;
        }
        break;
    }

    xcb_map_window(globalconf.connection, statusbar->sw->window);

    /* Set need update */
    statusbar->need_update = true;
}

/** Convert a statusbar to a printable string.
 * \param L The Lua VM state.
 *
 * \luastack
 * \lvalue A statusbar.
 */
static int
luaA_statusbar_tostring(lua_State *L)
{
    statusbar_t **p = luaA_checkudata(L, 1, "statusbar");
    lua_pushfstring(L, "[statusbar udata(%p) name(%s)]", *p, (*p)->name);
    return 1;
}

/** Create a new statusbar.
 * \param L The Lua VM state.
 *
 * \luastack
 * \lparam A table with at least a name attribute. Optionaly defined values are:
 * position, align, fg, bg, width and height.
 * \lreturn A brand new statusbar.
 */
static int
luaA_statusbar_new(lua_State *L)
{
    statusbar_t *sb;
    const char *buf;
    size_t len;

    luaA_checktable(L, 2);

    if(!(buf = luaA_getopt_string(L, 2, "name", NULL)))
        luaL_error(L, "object statusbar must have a name");

    sb = p_new(statusbar_t, 1);

    sb->name = a_strdup(buf);

    sb->colors.fg = globalconf.colors.fg;
    if((buf = luaA_getopt_lstring(L, 2, "fg", NULL, &len)))
        xcolor_init(&sb->colors.fg, globalconf.connection,
                    globalconf.default_screen, buf, len);

    sb->colors.bg = globalconf.colors.bg;
    if((buf = luaA_getopt_lstring(L, 2, "bg", NULL, &len)))
        xcolor_init(&sb->colors.bg, globalconf.connection,
                    globalconf.default_screen, buf, len);

    buf = luaA_getopt_lstring(L, 2, "align", "left", &len);
    sb->align = draw_align_fromstr(buf, len);

    sb->width = luaA_getopt_number(L, 2, "width", 0);
    if(sb->width > 0)
        sb->width_user = true;
    sb->height = luaA_getopt_number(L, 2, "height", 0);
    if(sb->height <= 0)
        /* 1.5 as default factor, it fits nice but no one knows why */
        sb->height = 1.5 * globalconf.font->height;

    buf = luaA_getopt_lstring(L, 2, "position", "top", &len);
    sb->position = position_fromstr(buf, len);

    sb->screen = SCREEN_UNDEF;

    return luaA_statusbar_userdata_new(L, sb);
}

/** Statusbar object.
 * \param L The Lua VM state.
 * \return The number of elements pushed on stack.
 * \luastack
 * \lfield screen Screen number.
 * \lfield align The alignment.
 * \lfield fg Foreground color.
 * \lfield bg Background color.
 * \lfield position The position.
 * \lfield widget The statusbar widgets.
 */
static int
luaA_statusbar_index(lua_State *L)
{
    size_t len;
    int i = 0;
    widget_node_t *witer;
    statusbar_t **statusbar = luaA_checkudata(L, 1, "statusbar");
    const char *attr = luaL_checklstring(L, 2, &len);

    if(luaA_usemetatable(L, 1, 2))
        return 1;

    switch(a_tokenize(attr, len))
    {
      case A_TK_SCREEN:
        if((*statusbar)->screen == SCREEN_UNDEF)
            return 0;
        lua_pushnumber(L, (*statusbar)->screen + 1);
        break;
      case A_TK_ALIGN:
        lua_pushstring(L, draw_align_tostr((*statusbar)->align));
        break;
      case A_TK_FG:
        luaA_pushcolor(L, &(*statusbar)->colors.fg);
        break;
      case A_TK_BG:
        luaA_pushcolor(L, &(*statusbar)->colors.bg);
        break;
      case A_TK_POSITION:
        lua_pushstring(L, position_tostr((*statusbar)->position));
        break;
      case A_TK_WIDGETS:
        lua_newtable(L);
        for(witer = (*statusbar)->widgets; witer; witer = witer->next)
        {
            luaA_widget_userdata_new(L, witer->widget);
            lua_rawseti(L, -2, ++i);
        }
        break;
      default:
        return 0;
    }

    return 1;
}

/** Remove a statubar from a screen.
 * \param statusbar Statusbar to detach from screen.
 */
static void
statusbar_remove(statusbar_t *statusbar)
{
    if(statusbar->screen != SCREEN_UNDEF)
    {
        position_t p;

        statusbar_systray_kickout(statusbar->phys_screen);

        /* save position */
        p = statusbar->position;
        statusbar->position = Off;
        statusbar_position_update(statusbar);
        /* restore position */
        statusbar->position = p;

        statusbar_list_detach(&globalconf.screens[statusbar->screen].statusbar, statusbar);
        globalconf.screens[statusbar->screen].need_arrange = true;
        statusbar->screen = SCREEN_UNDEF;
        statusbar_unref(&statusbar);
    }
}

/** Statusbar newindex.
 * \param L The Lua VM state.
 * \return The number of elements pushed on stack.
 */
static int
luaA_statusbar_newindex(lua_State *L)
{
    size_t len;
    statusbar_t *s, **statusbar = luaA_checkudata(L, 1, "statusbar");
    const char *buf, *attr = luaL_checklstring(L, 2, &len);
    position_t p;
    int screen;
    widget_node_t *witer;

    switch(a_tokenize(attr, len))
    {
      case A_TK_SCREEN:
        if(lua_isnil(L, 3))
            statusbar_remove(*statusbar);
        else
        {
            screen = luaL_checknumber(L, 3) - 1;

            luaA_checkscreen(screen);

            if((*statusbar)->screen == screen)
                luaL_error(L, "this statusbar is already on screen %d",
                           (*statusbar)->screen + 1);

            /* Check for uniq name and id. */
            for(s = globalconf.screens[screen].statusbar; s; s = s->next)
                if(!a_strcmp(s->name, (*statusbar)->name))
                    luaL_error(L, "a statusbar with that name is already on screen %d\n",
                               screen + 1);

            statusbar_remove(*statusbar);

            (*statusbar)->screen = screen;
            (*statusbar)->phys_screen = screen_virttophys(screen);

            statusbar_list_append(&globalconf.screens[screen].statusbar, *statusbar);
            statusbar_ref(statusbar);

            /* All the other statusbar and ourselves need to be repositioned */
            for(s = globalconf.screens[screen].statusbar; s; s = s->next)
                statusbar_position_update(s);

            ewmh_update_workarea((*statusbar)->phys_screen);
        }
        break;
      case A_TK_ALIGN:
        buf = luaL_checklstring(L, 3, &len);
        (*statusbar)->align = draw_align_fromstr(buf, len);
        statusbar_position_update(*statusbar);
        break;
      case A_TK_FG:
        if((buf = luaL_checklstring(L, 3, &len)))
            if(xcolor_init(&(*statusbar)->colors.fg, globalconf.connection,
                           globalconf.default_screen, buf, len))
            {
                if((*statusbar)->ctx)
                    (*statusbar)->ctx->fg = (*statusbar)->colors.fg;
                (*statusbar)->need_update = true;
            }
        break;
      case A_TK_BG:
        if((buf = luaL_checklstring(L, 3, &len)))
            if(xcolor_init(&(*statusbar)->colors.bg, globalconf.connection,
                           globalconf.default_screen, buf, len))
            {
                if((*statusbar)->ctx)
                    (*statusbar)->ctx->bg = (*statusbar)->colors.bg;

                (*statusbar)->need_update = true;
            }
        break;
      case A_TK_POSITION:
        buf = luaL_checklstring(L, 3, &len);
        p = position_fromstr(buf, len);
        if(p != (*statusbar)->position)
        {
            (*statusbar)->position = p;
            for(s = globalconf.screens[(*statusbar)->screen].statusbar; s; s = s->next)
                statusbar_position_update(s);
            ewmh_update_workarea((*statusbar)->phys_screen);
        }
        break;
      case A_TK_WIDGETS:
        luaA_checktable(L, 3);

        /* remove all widgets */
        for(witer = (*statusbar)->widgets; witer; witer = (*statusbar)->widgets)
        {
            if(witer->widget->detach)
                witer->widget->detach(witer->widget, *statusbar);
            widget_unref(&witer->widget);
            widget_node_list_detach(&(*statusbar)->widgets, witer);
            p_delete(&witer);
        }

        (*statusbar)->need_update = true;

        /* now read all widgets and add them */
        lua_pushnil(L);
        while(lua_next(L, 3))
        {
            widget_t **widget = luaA_checkudata(L, -1, "widget");
            widget_node_t *w = p_new(widget_node_t, 1);
            w->widget = *widget;
            widget_node_list_append(&(*statusbar)->widgets, w);
            widget_ref(widget);
            lua_pop(L, 1);
        }
        break;
      default:
        return 0;
    }

    return 0;
}

const struct luaL_reg awesome_statusbar_methods[] =
{
    { "__call", luaA_statusbar_new },
    { NULL, NULL }
};
const struct luaL_reg awesome_statusbar_meta[] =
{
    { "__index", luaA_statusbar_index },
    { "__newindex", luaA_statusbar_newindex },
    { "__gc", luaA_statusbar_gc },
    { "__eq", luaA_statusbar_eq },
    { "__tostring", luaA_statusbar_tostring },
    { NULL, NULL },
};

// vim: filetype=c:expandtab:shiftwidth=4:tabstop=8:softtabstop=4:encoding=utf-8:textwidth=80
