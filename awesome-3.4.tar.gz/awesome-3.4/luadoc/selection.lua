--- awesome selection (clipboard) API
-- @author Julien Danjou &lt;julien@danjou.info&gt;
-- @copyright 2008-2009 Julien Danjou
module("selection")

--- Get the selection (clipboard) content.
-- @param -
-- @return A string with the selection (clipboard) content.
-- @name selection
-- @class function
